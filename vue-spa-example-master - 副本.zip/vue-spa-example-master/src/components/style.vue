<style lang="stylus">
@import "../stylus/variables.styl";
@import "../stylus/iScroll.styl";
</style>