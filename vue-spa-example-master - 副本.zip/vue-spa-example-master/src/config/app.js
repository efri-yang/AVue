/*
 * Created by toplan on 16/3/3.
 */
module.exports = {
  name: 'ti_ku_student_end',
  debug: true,
  api: {
    root: 'http://...',
    version: 'v1'
  }
}
