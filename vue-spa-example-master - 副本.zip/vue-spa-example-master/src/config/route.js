/*
 * Created by toplan on 16/3/2.
 */
module.exports = {
  linkActiveClass: 'active',
  redirect: {
    '*': '/login',
    '/': '/login'
  }
}
