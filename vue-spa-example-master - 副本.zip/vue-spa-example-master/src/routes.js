/**
 * Created by toplan on 16/3/2.
 */
module.exports = {
  '/': {
    auth: false,
    history: false,
    component: require('./App.vue')
  }
}
