/*
 * Created by toplan on 16/3/2.
 */
var extend = require('./common.js').extend

extend(module.exports, require('./common.js'))
extend(module.exports, require('./iScroll.js'))
extend(module.exports, require('./store.js'))
