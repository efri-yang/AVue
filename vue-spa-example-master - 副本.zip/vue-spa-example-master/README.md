# vue-spa-example
vue single page app example base on Vue-cli

### skill stack
- vue.js
- vue-router
- vue-resource
- vue-touch
